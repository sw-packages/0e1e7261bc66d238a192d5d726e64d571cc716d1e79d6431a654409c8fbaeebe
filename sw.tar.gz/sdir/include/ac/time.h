/* Generic time.h */
/* $OpenLDAP$ */
/* This work is part of OpenLDAP Software <http://www.openldap.org/>.
 *
 * Copyright 1998-2022 The OpenLDAP Foundation.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted only as authorized by the OpenLDAP
 * Public License.
 *
 * A copy of this license is available in file LICENSE in the
 * top-level directory of the distribution or, alternatively, at
 * <http://www.OpenLDAP.org/license.html>.
 */

#ifndef _AC_TIME_H
#define _AC_TIME_H

#if defined(HAVE_SYS_TIME_H)
# include <sys/time.h>
# ifdef HAVE_SYS_TIMEB_H
#  include <sys/timeb.h>
# endif
#endif
# include <time.h>

#if defined(_WIN32) && !defined(HAVE_CLOCK_GETTIME)
	struct timespec {
		time_t	tv_sec;
		int 	tv_nsec;
	};
#endif

#endif /* _AC_TIME_H */
